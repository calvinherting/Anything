#include "Header.h"

void readData(FILE* infile, FitbitData data[])
{
}
